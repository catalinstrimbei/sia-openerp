package org.open.erp.services.proman.impl;

import java.util.Date;

import org.open.erp.services.proman.Proiect;

/**
 * 
 * @BusinessObject(Service)
 * 
 */
public class ProcesorProiecte {
	public Double getCostProiectInCurs(Proiect proiect, Date dataRef){
		Double cost = 0.0;
		
		return cost;
	}
	
	public Double getBugetProiectInCurs(Proiect proiect, Date dataRef){
		Double buget = 0.0;
		
		return buget;
	}
	
}
