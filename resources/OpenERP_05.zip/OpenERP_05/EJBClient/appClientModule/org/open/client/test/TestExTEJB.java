package org.open.client.test;

import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.BeforeClass;
import org.junit.Test;
import org.open.services.exjta.ExTEJBSrv;
import org.open.services.exjtaref.ExFirstEJBSrv;
import org.open.services.exjtaref.ExTBigEJB;
import org.open.services.exjtaref.ExTBigEJBSrv;

public class TestExTEJB {
	
	static ExTEJBSrv exTEJBsrv;
	static ExTBigEJBSrv exTBigEJBSrv;
	static InitialContext ctx;	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ctx = initJBossJNDICtx(); 
		exTEJBsrv = (ExTEJBSrv) ctx.lookup("ExTEJB/remote");
		exTBigEJBSrv = (ExTBigEJBSrv) ctx.lookup("ExTBigEJB/remote");
	}
	
	//@Test /* Test transactii simple - BMT*/
	public void testDoBusinessAction(){
		String actionResult = exTEJBsrv.doBusinessAction("test action - 13 [1]");
		System.out.println(actionResult);
	}
	//@Test /* Test transactii simple - CMT*/
	public void testDoBusinessActivity(){
		String actionResult = exTEJBsrv.doBusinessActivity("test activity - 10 [1]");
		System.out.println(actionResult);
	}
	
	
	//@Test /* Test transactii compuse - BMT [xyz]=x(TAgregat:0Commit,1Roll)y(SubTFirst:0,1)z(SubTSeconft:0,1)*/
	public void testDoAggregateBusinessAction(){
		String actionResult = exTEJBsrv.doAggregateBusinessAction("test aggregate-action - 22 [011]");
		System.out.println(actionResult);
	}	
		
	//@Test /* Test transactii compuse */
	public void testXAggregateBusinessAction(){
		String actionResult = exTEJBsrv.xAggregateBusinessAction("test aggregate-action - 30 [101]");
		System.out.println(actionResult);
	}		
	
	@Test /* Test tranzactii distribuite - multi EJB - CMT. TODO: 2Fase Commit cu 2 surse diferite postgresql*/
	public void testRefXAggregateBusinessAction(){
		String actionResult = exTBigEJBSrv.xAggregateBusinessAction("test aggregate-action - 55 [111]");
		System.out.println(actionResult);
	}	
	
	
	/* JNDI Initialization Context -------------------------------------------------------*/
	private static InitialContext initJBossJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");		
        props.put("java.naming.provider.url", "jnp://localhost:1099/");
        props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
        return new InitialContext(props);
	}	
}
/*

 <datasources>
 <xa-datasource>
 <jndi-name>kernelDS</jndi-name>
 <track-connection-by-tx/>
 <isSameRM-override-value>false</isSameRM-override-value>
 <xa-datasource-class>oracle.jdbc.xa.client.OracleXADataSource</xa-datasource-class>
 <xa-datasource-property name="URL">jdbc:oracle:thin:@(DESCRIPTION=(ENABLE=BROKEN)(ADDRESS_LIST=(ADDRESS = (PROTOCOL = TCP)(HOST = rac04no22.globoi.com)(PORT = 1521))(ADDRESS = (PROTOCOL = TCP)(HOST = rac04no23.globoi.com)(PORT = 1521))(ADDRESS = (PROTOCOL = TCP)(HOST = rac04no24.globoi.com)(PORT = 1521))(FAILOVER=on)(LOAD_BALANCE=off))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=SRV_CAD_ISP)))
 </xa-datasource-property>
 <xa-datasource-property name="User">xyztr</xa-datasource-property>
 <xa-datasource-property name="Password">xyztr</xa-datasource-property>
 <exception-sorter-class-name>org.jboss.resource.adapter.jdbc.vendor.OracleExceptionSorter</exception-sorter-class-name>
 
 <track-statements>true</track-statements>
 <prepared-statement-cache-size>100</prepared-statement-cache-size>
 
 <min-pool-size>5</min-pool-size>
 <max-pool-size>15</max-pool-size>
 <blocking-timeout-millis>30000</blocking-timeout-millis>
 <new-connection-sql>select count(0) from dual</new-connection-sql>
 <check-valid-connection-sql>select count(0) from dual</check-valid-connection-sql>
 <idle-timeout-minutes>0</idle-timeout-minutes>
 
 <no-tx-separate-pools/>
 </xa-datasource>
</datasources>

*/

/*

<datasources>
	<xa-datasource>
		<jndi-name>jdbc/LocalPG_XA</jndi-name>
		<xa-datasource-property name="ServerName">localhost</xa-datasource-property>
		<xa-datasource-property name="PortNumber">5432</xa-datasource-property>
		<xa-datasource-property name="DatabaseName">postgres</xa-datasource-property>
		<xa-datasource-property name="User">openerp</xa-datasource-property>
		<xa-datasource-property name="Password">openerp</xa-datasource-property>
		<xa-datasource-class>org.postgresql.xa.PGXADataSource</xa-datasource-class>
	</xa-datasource>   
	  
	<xa-datasource> 
		<jndi-name>jdbc/FEAA_ORCL_XA</jndi-name> 
		<track-connection-by-tx>true</track-connection-by-tx> 
		<isSameRM-override-value>false</isSameRM-override-value> 
		<xa-datasource-class>oracle.jdbc.xa.client.OracleXADataSource</xa-datasource-class> 
		<xa-datasource-property name="URL">jdbc:oracle:thin:@10.10.0.7:1521:ORCL</xa-datasource-property> 
		<xa-datasource-property name="User">catalin</xa-datasource-property> 
		<xa-datasource-property name="Password">catalin</xa-datasource-property> 
		<exception-sorter-class-name>
			org.jboss.resource.adapter.jdbc.vendor.OracleExceptionSorter 
		</exception-sorter-class-name> 
		<no-tx-separate-pools/> 
	</xa-datasource> 
					
	<mbean code="org.jboss.resource.adapter.jdbc.vendor.OracleXAExceptionFormatter" 
		   name="jboss.jca:service=OracleXAExceptionFormatter"> 
		<depends optional-attribute-name="TransactionManagerService">
			jboss:service=TransactionManager 
		</depends> 
	</mbean>  
	  
	<local-tx-datasource>
	  <jndi-name>jdbc/LocalPG_TX</jndi-name>
	  <connection-url>jdbc:postgresql://localhost:5432/postgres</connection-url>
	  <driver-class>org.postgresql.Driver</driver-class>
	  <user-name>openerp</user-name>
	  <password>openerp</password>
	  <min-pool-size>5</min-pool-size>
	  <max-pool-size>20</max-pool-size>
	  <idle-timeout-minutes>0</idle-timeout-minutes>
	</local-tx-datasource>
</datasources>

*/