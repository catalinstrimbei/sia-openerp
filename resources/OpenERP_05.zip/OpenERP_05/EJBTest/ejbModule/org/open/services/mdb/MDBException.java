package org.open.services.mdb;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class MDBException extends RuntimeException{

	public MDBException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MDBException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
