package org.open.services.exjta;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class ExTEJBException extends RuntimeException{

	public ExTEJBException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExTEJBException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
