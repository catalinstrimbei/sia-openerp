package org.open.services.exjtaref;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.ApplicationException;
import javax.ejb.EJB;
import javax.ejb.PostActivate;
import javax.ejb.PrePassivate;
import javax.ejb.Remove;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.sql.XAConnection;
import javax.sql.XADataSource;
import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;
import javax.transaction.xa.XAResource;

import org.apache.log4j.Logger;
import org.open.services.test1.Test1Local;
import org.open.services.test2.Test2Local;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ExSecondEJB implements ExSecondEJBSrv {
	Logger logger = Logger.getLogger(this.getClass().getName());
    public ExSecondEJB() { }	
	/* Resurse injectatate */
	@Resource
	private SessionContext context;	
	@Resource(mappedName="java:jdbc/LocalPG_XA")
	private DataSource ds;
	/* INTERCEPTORI  Life cycle */
	@PostConstruct
	void init(){
		//initializeaza resurse neinjectate (folosind, de obicei, SessionContext)
		logger.info("**** @PostConstruct: initializeaza resurse neinjectate (folosind, de obicei, SessionContext)!");		
	}	    
	@PrePassivate
	public void onPassivate() {
		//inchide conexiunile externe si seteaza null toti membrii neserializabili
		logger.info("**** @PrePassivate: inchide conexiunile externe si seteaza null toti membrii neserializabili!");
	}
	@PostActivate
	public void onActivate() {
		//redeschide conexiunile si initializeaza membrii non-serializabili
		logger.info("**** @PostActivate: redeschide conexiunile si initializeaza membrii non-serializabili!");
	}
	@Remove
	public void disconnect() {
		//sterge obiectul, din memoria serverului, la invocarea acestei metode
		logger.info("**** disconnect: sterge obiectul, din memoria serverului, la invocarea acestei metode!");
	}
	@PreDestroy
	public void closeFile() {
		//containerul va invoca aceasta metoda inainte de distrugerea obiectului
		logger.info("**** @PreDestroy: containerul va invoca aceasta metoda inainte de distrugerea obiectului!");
	}
	
	/*--------------------------------------*/
	private static InitialContext initJBossJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");		
        props.put("java.naming.provider.url", "jnp://localhost:1099/");
        props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
        return new InitialContext(props);
	}
	/*private static InitialContext initGlassfishJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.enterprise.naming.SerialInitContextFactory");
        props.setProperty("org.omg.CORBA.ORBInitialHost", "localhost");
        // glassfish default port value will be 3700,
        props.setProperty("org.omg.CORBA.ORBInitialPort", "3700");	
        return new InitialContext(props);
	}	*/
	
	
	/* Servicii business oferite ***********************************************************************/
	/* Pre-conditii context EJB:
	 * @TransactionManagement(TransactionManagementType.CONTAINER)
	 * si, in mod implicit,
	 * @TransactionAttribute(TransactionAttributeType.REQUIRED)
	 */		
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	@Override
	public String xSecondBusinessAction(String message){
		String result = " ... do " + message;
		Connection conn = null;
		try{
			/* Set-up section
			 * Pentru  TransactionManagementType.CONTAINER acesta este momentul
			 * deschiderii sau achizitionarii tranzactiei
			 * */ 
			conn = ds.getConnection();
			
			/* Tranzactia nu trebuie initializata explicit:
			 * apelul precedent/superior - tranz.implicita - deci REQUIRED, apelul curent - tranz.implicita - deci REQUIRE
			 * */
			Statement stmtx = conn.createStatement();			
			PreparedStatement insert = conn
					.prepareStatement("INSERT INTO \"LOG\" VALUES(?, ?)");
			insert.setTimestamp(1,
					new java.sql.Timestamp(new java.util.Date().getTime()));
			insert.setString(2, "2nd=" + message);
			insert.execute();
			
			/* Finalize transaction */
			String transactionFlag = message.substring(message.indexOf("[") + 3, message.indexOf("[") + 4);
			if (transactionFlag.equals("1")){
				/* Pentru COMMIT- nimic de facut - inseamna delegarea responsabilitatii super-transactiei
				 * Sub-tranzactia se va comite daca se comite si tranzactia superioara.
				 * */
				logger.info("COMMIT flag for xSECOND business action - " + transactionFlag);
				logger.info("CONFIRMED xSECOND business action - TF=" + transactionFlag);
			}else{
				logger.info("ROLL flag for xSECOND business action - " + transactionFlag);
				/* Pentru ROLLBACK - */
				//context.setRollbackOnly();
				logger.info("ROLLED-BACK MARKED xSECOND business action - TF=" + transactionFlag);
				
				/* Pentru ROLLBACK Varianta 2:
				 * ROLLBACK se va realiza la aruncarea unei exceptii generice
				 * sau un @ApplicationException(rollback=true)
				 * Daca @ApplicationException(rollback=false),
				 * exceptia determina totusi COMMIT 
				 * */
				throw new ExTBigEJBException("Exception to ROLLBACK xSECOND business action - TF=" + transactionFlag);		
			}
		}catch(Exception ex){
			logger.error("ExTEJB -> xSecondBusinessAction failed!");
			result = " ... doing " + message + " from xSecondBusinessAction failed!";
			/* Ar trebui apel
			 * context.setRollbackOnly();
			 * */
			
			if (ex instanceof ExTBigEJBException){
				/* Pentru ROLLBACK Varianta 2: */
				throw (ExTBigEJBException)ex;
			}else
				ex.printStackTrace();
		}finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                System.out.println("Note:  Cleanup exception.");
                e.printStackTrace();
            }
        }
		return result;
	}
}