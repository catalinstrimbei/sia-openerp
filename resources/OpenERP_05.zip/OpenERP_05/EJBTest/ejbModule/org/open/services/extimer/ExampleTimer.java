package org.open.services.extimer;

public interface ExampleTimer {
	   void scheduleTimer(long milliseconds);
}