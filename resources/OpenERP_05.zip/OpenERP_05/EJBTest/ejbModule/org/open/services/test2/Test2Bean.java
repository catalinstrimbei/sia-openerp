package org.open.services.test2;

import javax.ejb.Stateless;

/* Declararea interfetelor se realizează la nivelul clasei de implementare
 * Clasa de implementare componenta EJB stateless cu declaraţia numelui JNDI 
 * */
@javax.ejb.Remote({Test2Remote.class})
@javax.ejb.Local({Test2Local.class})
//@Stateless(mappedName="Test2Bean/remote")
@Stateless //Numele default in JBoss <NumeClasaEJBean>/remote si <NumeClasaEJBean>/local
public class Test2Bean implements Test2Remote, Test2Local{
	
	public String say(String mess){
		this.message = mess;
		return "Test2Bean say:" + mess;
	}
	
	/* Test conversational */
	private String message = "Default";
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}	
}
