package org.open.services.exref;

import java.sql.SQLException;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.PostActivate;
import javax.ejb.PrePassivate;
import javax.ejb.Remove;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.sql.XADataSource;

import org.apache.log4j.Logger;
import org.open.services.test1.Test1Local;
import org.open.services.test2.Test2Local;

/**
 * Session Bean implementation class ProEJB
 */
//@Stateless(mappedName="ProEJB/remote")
@Stateless //Numele default in JBoss <NumeClasaEJBean>/remote si <NumeClasaEJBean>/local
@TransactionManagement(TransactionManagementType.CONTAINER)
public class BigEJB implements BigEJBSrv {
	Logger logger = Logger.getLogger(this.getClass().getName());
	
	@Resource
	private SessionContext context;	

	public BigEJB() {
        
    }
	
	public String sayBigEJB(String mess){
		return "SaysBigEJB: " + mess;
	}
    
	/* Compunerea serviciilor - init injection 
	 * @EJB - Se cauta numele default in JBoss <NumeClasaEJBean>/local daca atributul este de tipul interfetei locale
	 * @EJB(mappedName="EJBean/local") 
	 * */	 
	@EJB //
	private Test1Local test1;	
	/* Compunerea serviciilor - init injection */
	@EJB
	private Test2Local test2;
	/* Compunerea serviciilor  - init PostConstruct */
	private Test2Local test3;	
	
	public String sayMessageToTest1(String message){
		String result = "SaysBigEJB to test1: " + test1.say(message);
		return result;
	}	
	public String sayMessageToTest3(String message){
		String result = "SaysBigEJB to test3: " + test3.say(message);
		return result;
	}	
	/* AOP Interceptors */
	@Interceptors({BigEJBLogInterceptor.class})
	public String sayMessageToTest2(String message){
		String result = "SaysBigEJB to test2: " + test2.say(message);
		return result;
	}
	
	
	/* AOP Lifecycle */
	@PostConstruct
	void init(){
		if (test3 == null){
			try {
				/* Context initializat explicit */
				//Context ctx = new javax.naming.InitialContext();
				//Context context = initJBossJNDICtx();

				/* Context injectat */
				test3 = (Test2Local) context.lookup("Test2Bean/local");
				logger.info("**** PostConstruct: Initializare explicita test3 ...");
				logger.info("#### test1: " + (this.test1 !=null ? " is injected, ":" isn't injected, ") +
						"test2: " + (this.test2!=null? " is injected, ":" isn't injected, ")
						);				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
	}
	
	/* Alti INTERCEPTORI ----------------------------------------------------*/
	@PrePassivate
	public void onPassivate() {
		//inchide conexiunile externe si seteaza null toti membrii neserializabili
		logger.info("**** @PrePassivate: inchide conexiunile externe si seteaza null toti membrii neserializabili!");
	}
	@PostActivate
	public void onActivate() {
		//redeschide conexiunile si initializeaza membrii non-serializabili
		logger.info("**** @PostActivate: redeschide conexiunile si initializeaza membrii non-serializabili!");
	}
	@Remove
	public void disconnect() {
		//sterge obiectul, din memoria serverului, la invocarea acestei metode
		logger.info("**** @Remove: sterge obiectul, din memoria serverului, la invocarea acestei metode!");
	}
	@PreDestroy
	public void closeFile() {
		//containerul va invoca aceasta metoda inainte de distrugerea obiectului
		logger.info("**** @PreDestroy: containerul va invoca aceasta metoda inainte de distrugerea obiectului!");
	}
	
	
	/* Logica implementare initializare explicit context */
	private static InitialContext initJBossJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");		
        props.put("java.naming.provider.url", "jnp://localhost:1099/");
        props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
        return new InitialContext(props);
	}
	/*private static InitialContext initGlassfishJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.enterprise.naming.SerialInitContextFactory");
        props.setProperty("org.omg.CORBA.ORBInitialHost", "localhost");
        // glassfish default port value will be 3700,
        props.setProperty("org.omg.CORBA.ORBInitialPort", "3700");	
        return new InitialContext(props);
	}	*/

	public Test1Local getTest1() {
		return test1;
	}

	public Test2Local getTest2() {
		return test2;
	}

	public Test2Local getTest3() {
		return test3;
	}
	
	
	
}
