package org.open.erp.services.proman;

import javax.ejb.Local;

//import javax.ejb.Remote;

@Local
public interface ProjectManagementSrvLocal extends ProjectManagementSrv{

}
