package org.open.services.exjta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;
import javax.sql.XAConnection;
import javax.sql.XADataSource;
import javax.transaction.xa.XAResource;

public class ExTDBLogger {
	//private DataSource ds;
	private XADataSource ds;
	private Connection dbConnection;

	public ExTDBLogger(XADataSource ds) {
		super();
		this.ds = ds;
		/*
		try {
			dbConnection = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		*/
		XAConnection xaConn;
		try {
			xaConn 				 = ds.getXAConnection();
	        XAResource    xaRes  = xaConn.getXAResource();
	        dbConnection      	 = xaConn.getConnection();				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	/*
	public DBLogger(Connection con) {
		super();
		this.dbConnection = con;
	}	
	*/
	public void log(String message) {
		try {
			/*
			if (dbConnection == null)
				dbConnection = ds.getConnection();
			*/
			PreparedStatement insert = dbConnection
					.prepareStatement("INSERT INTO \"LOG\" VALUES(?, ?)");
			insert.setTimestamp(1,
					new java.sql.Timestamp(new java.util.Date().getTime()));
			insert.setString(2, message);
			insert.execute();
			//insert.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/*
	public void clean() throws SQLException {
		if (dbConnection != null)
			dbConnection.close();
	}
	*/
}
