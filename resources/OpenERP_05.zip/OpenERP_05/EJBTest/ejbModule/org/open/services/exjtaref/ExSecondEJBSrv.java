package org.open.services.exjtaref;

import javax.ejb.Local;

@Local
public interface ExSecondEJBSrv {
	/* Part of Declarative Distributed JTA with JDBC*/
	String xSecondBusinessAction(String message);
}
