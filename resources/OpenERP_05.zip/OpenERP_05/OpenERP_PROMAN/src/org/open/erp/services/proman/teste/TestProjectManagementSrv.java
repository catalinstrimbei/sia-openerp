package org.open.erp.services.proman.teste;

import static org.junit.Assert.assertNotNull;

import java.util.Calendar;
import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;
import org.open.erp.services.proman.Activitate;
import org.open.erp.services.proman.Proiect;
import org.open.erp.services.proman.ProjectManagementSrv;
import org.open.erp.services.proman.Responsabil;

public class TestProjectManagementSrv {
	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TestProjectManagementSrv.class.getName());
	static ProjectManagementSrv promanInstance;
//	static NomenclatoareSrv nomenclatorInstance;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//promanInstance= ProjectManagementDummyFactory.getProjectManagementSrv();
		System.out.println("PromanInstance initiated!");
		
		//nomenclatorInstance = ProjectManagementDummyFactory.getNomenclatoareSrv();
		logger.info("initTest " + promanInstance);		
		
	}

	//@Before
	public void setUp() throws Exception {
		//promanInstance= ProjectManagementDummyFactory.getProjectManagementSrv();
		System.out.println("PromanInstance initiated!");
		
		//nomenclatorInstance = ProjectManagementDummyFactory.getNomenclatoareSrv();
		logger.info("initTest " + promanInstance);		
	}

	@Test
	public void testCreareProiect() throws Exception {
		logger.info("Begin test: creareProiect");
		
		Double valoareBugetata = 0.0;
		Proiect proiect = promanInstance.creareProiect("Test", null, null, null, valoareBugetata);
		assertNotNull("Nu exista proiect nou!", proiect);
		//assertNotNull("Proiectul nu are buget alocat!", proiect.getBuget());
		//assertEquals("Valoarea bugetata nu concorda cu bugetul alocat!", valoareBugetata, proiect.getBuget().getValoareBuget());
		
		logger.info("End test: creareProiect");
	}

	@Test
	public void testCreareActivitate() throws Exception  {
		logger.info("Begin test: creareActivitate");
		Proiect proiect = promanInstance.creareProiect("Test", null, null, null, 1000.0);
		Responsabil responsabil = null; // nomenclatorInstance.getPersoanaCuId(1);
		
		Calendar calendarStart = Calendar.getInstance();
		Calendar calendarEnd = Calendar.getInstance();
		
		calendarStart.setTime(new Date());
		calendarEnd.setTime(new Date()); calendarEnd.add(Calendar.WEEK_OF_MONTH, 2);
		Activitate activitate1 = promanInstance.creareActivitate(proiect, responsabil, "Prima activitate test", 
				calendarStart.getTime(), calendarEnd.getTime(), 500.0);

		
		logger.info("End test: creareActivitate");
	}

	@Test
	public void testStartProiect() throws Exception {
		logger.info("Begin test: startProiect");
		
		Proiect proiect = promanInstance.creareProiect("Test", null, null, null, 1000.0);
		Responsabil responsabil = null; //nomenclatorInstance.getPersoanaCuId(1);
		
		Calendar calendarStart = Calendar.getInstance();
		Calendar calendarEnd = Calendar.getInstance();
		
		calendarStart.setTime(new Date());
		calendarEnd.setTime(new Date()); calendarEnd.add(Calendar.WEEK_OF_MONTH, 2);
		Activitate activitate1 = promanInstance.creareActivitate(proiect, responsabil, "Prima activitate test", 
				calendarStart.getTime(), calendarEnd.getTime(), 500.0);
		
		//proiect = activitate1.getProiect();
		
		calendarStart.add(Calendar.MONTH, 2);
		calendarEnd.add(Calendar.WEEK_OF_MONTH, 6);
		Activitate activitate2 = promanInstance.creareActivitate(proiect, responsabil, "Prima activitate test", 
				calendarStart.getTime(), calendarEnd.getTime(), 500.0);
		
		//proiect = activitate2.getProiect();
		
		logger.info("End test: startProiect");
		
	}

	@Test
	public void testProgresActivitate() throws Exception {
		logger.info("Begin test: progresActivitate");
		
		Proiect proiect = promanInstance.creareProiect("Test", null, null, null, 1000.0);
		Responsabil responsabil = null; //nomenclatorInstance.getPersoanaCuId(1);
		
		Calendar calendarStart = Calendar.getInstance();
		Calendar calendarEnd = Calendar.getInstance();
		
		calendarStart.setTime(new Date());
		calendarEnd.setTime(new Date()); calendarEnd.add(Calendar.WEEK_OF_MONTH, 2);
		Activitate activitate1 = promanInstance.creareActivitate(proiect, responsabil, "Prima activitate test", 
				calendarStart.getTime(), calendarEnd.getTime(), 500.0);
		
		//proiect =  activitate1.getProiect();
		
		calendarStart.add(Calendar.MONTH, 2);
		calendarEnd.add(Calendar.WEEK_OF_MONTH, 6);
		Activitate activitate2 = promanInstance.creareActivitate(proiect, responsabil, "Prima activitate test", 
				calendarStart.getTime(), calendarEnd.getTime(), 500.0);
		
		//proiect =  activitate2.getProiect();

		promanInstance.startProiect(proiect);
		
		promanInstance.progresActivitate(activitate1, 20.0, 350.0, new Date());
		
		logger.info("End test: progresActivitate");
	}

	
	/* --------- Teste functionale/use cases -----------------------------------------*/
	public void testUseCaseInitiereProiect(){
		//TODO:
	}
	public void testUseCaseActualizareStatusProiect(){
		//TODO:
	}
	
}

