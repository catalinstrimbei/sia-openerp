package org.open.services.test2;

/* Interfaţa EJB Remote (clientul EJB rulează în alt spaţiu JRE faţă de componenta EJB) */
public interface Test2Remote extends Test2 {

}
