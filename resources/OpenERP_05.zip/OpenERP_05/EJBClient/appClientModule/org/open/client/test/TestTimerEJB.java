package org.open.client.test;

import static org.junit.Assert.*;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.open.services.exref.BigEJBSrv;
import org.open.services.extimer.ExampleTimer;
import org.open.services.test1.Test1;
import org.open.services.test2.Test2;

public class TestTimerEJB {
	static ExampleTimer test1;
	static InitialContext ctx;

	static String test1Name = "ExampleTimerBean/remote";
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ctx = initJBossJNDICtx(); 
		test1 = (ExampleTimer) ctx.lookup(test1Name);
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test /* Test Timer */
	public void test1() throws NamingException {
		System.out.println("test1 =" + test1);
		test1.scheduleTimer(5000); //miliseconds
		
	}
	
	
	/* JNDI Initialization Context -------------------------------------------------------*/
	private static InitialContext initJBossJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");		
        props.put("java.naming.provider.url", "jnp://localhost:1099/");
        props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
        return new InitialContext(props);
	}
	
	private static InitialContext initGlassfishJNDICtx() throws NamingException{
		Properties props = new Properties();
		/*
        props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.enterprise.naming.SerialInitContextFactory");
        props.setProperty("org.omg.CORBA.ORBInitialHost", "localhost");
        // glassfish default port value will be 3700,
        props.setProperty("org.omg.CORBA.ORBInitialPort", "1099");
        */
        props.put("java.naming.factory.initial", "com.sun.enterprise.naming.SerialInitContextFactory");		
        //props.put("java.naming.provider.url", "jnp://localhost:1099/"); //default
        //props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");		
        return new InitialContext(props);
	}
	
}

/* JBoss's jndi properties
java.naming.factory.initial=org.jnp.interfaces.NamingContextFactory
java.naming.provider.url = iiop://localhost:1099
java.naming.factory.url.pkgs= org.jboss.naming:org.jnp.interfaces
*/

/* Glassfish's jndi properties
java.naming.factory.initial=org.jnp.interfaces.NamingContextFactory
java.naming.provider.url = iiop://localhost:3700
java.naming.factory.url.pkgs= org.jboss.naming:org.jnp.interfaces
*/
