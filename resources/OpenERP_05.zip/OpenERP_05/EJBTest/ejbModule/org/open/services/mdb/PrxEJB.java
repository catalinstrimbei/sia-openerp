package org.open.services.mdb;

import java.util.Date;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnectionFactory;

/**
 * Session Bean implementation class PrxEJB
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PrxEJB implements PrxEJBSrv {


	@Resource(mappedName="ServiceMDBTopicConnectionFactory")
	//@Resource(mappedName="/ConnectionFactory")
	private TopicConnectionFactory topicConnectionFactory;
	
	@Resource(mappedName="ServiceMDBTopicConnectionFactory")
	//@Resource(mappedName="/ConnectionFactory")
	private QueueConnectionFactory queueConnectionFactory;	
	
	@Resource(mappedName="ServiceMDBTopic")
	private Topic topic;	

	@Resource(mappedName="ServiceMDBQueue")
	private Queue queue;		
	
    public PrxEJB() {
        // TODO Auto-generated constructor stub
    }

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public String forwardTopicMessage(Date dataMesaj, String textMesaj) {
		String resultJMS = "Success";
		Session topicSession = null;
		Connection connection = null;
		try{
			connection = topicConnectionFactory.createConnection();
			connection.start();
			topicSession = connection.createSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageProducer publisher = topicSession.createProducer(topic);
			MapMessage message =topicSession.createMapMessage();
			message.setLong("dataMesaj", dataMesaj.getTime());
			message.setString("textMesaj", textMesaj + "[TopicConnectionFactory: ServiceMDBTopicConnectionFactory]");
			publisher.send(message);
			
		}catch(JMSException ex){
			ex.printStackTrace();
			resultJMS = "Failed";
			try {
				if (topicSession != null)
					topicSession.close();
				if (connection != null)
					connection.close();  
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
  			
		}
		
		return "Forwarding message on topic:" + textMesaj + ": " + resultJMS + "!";
		
	}

	@Override
	public String forwardQueueMessage(Date dataMesaj, String textMesaj) {
		String resultJMS = "Success";
		Session queueSession = null;
		Connection connection = null;
		try{
			connection = queueConnectionFactory.createConnection();
			connection.start();
			queueSession = connection.createSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageProducer publisher = queueSession.createProducer(queue);
			MapMessage message =queueSession.createMapMessage();
			message.setLong("dataMesaj", dataMesaj.getTime());
			message.setString("textMesaj", textMesaj + "[QueueConnectionFactory: ServiceMDBTopicConnectionFactory]");
			publisher.send(message);
			
		}catch(JMSException ex){
			ex.printStackTrace();
			resultJMS = "Failed";
			try {
				if (queueSession != null)
					queueSession.close();
				if (connection != null)
					connection.close();  
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		
		return "Forwarding message on queue:" + textMesaj + ": " + resultJMS + "!";
	}

}

/*

deploy\messaging: destinations-service.xml
pentru @Resource(mappedName="ServiceMDBTopic") si @Resource(mappedName="ServiceMDBQueue")
----------------------------------------------------------------------------------------------
	<mbean code="org.jboss.jms.server.destination.TopicService"
		   name="jboss.messaging.destination:service=Topic,name=ServiceMDBTopic"
		   xmbean-dd="xmdesc/Topic-xmbean.xml">
		<attribute name="JNDIName">ServiceMDBTopic</attribute>
	   <depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
	   <depends>jboss.messaging:service=PostOffice</depends>
	</mbean>   

   <mbean code="org.jboss.jms.server.destination.QueueService"
      name="jboss.messaging.destination:service=Queue,name=ServiceMDBQueue"
      xmbean-dd="xmdesc/Queue-xmbean.xml">
	  <attribute name="JNDIName">ServiceMDBQueue</attribute>
      <depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
	  <depends>jboss.messaging:service=PostOffice</depends>
   </mbean>  
   
----------------------------------------------------------------------------------------------
deploy\messaging: connection-factories-service.xml
pentru @Resource(mappedName="/ConnectionFactory")
----------------------------------------------------------------------------------------------
   <mbean code="org.jboss.jms.server.connectionfactory.ConnectionFactory"
      name="jboss.messaging.connectionfactory:service=ConnectionFactory"
      xmbean-dd="xmdesc/ConnectionFactory-xmbean.xml">
      <depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
      <depends optional-attribute-name="Connector">jboss.messaging:service=Connector,transport=bisocket</depends>
      <depends>jboss.messaging:service=PostOffice</depends>
      
      <attribute name="JNDIBindings">
         <bindings>
            <binding>/ConnectionFactory</binding>
            <binding>/XAConnectionFactory</binding>
            <binding>java:/ConnectionFactory</binding>
            <binding>java:/XAConnectionFactory</binding>
         </bindings>
      </attribute>
   </mbean>
----------------------------------------------------------------------------------------------
*/