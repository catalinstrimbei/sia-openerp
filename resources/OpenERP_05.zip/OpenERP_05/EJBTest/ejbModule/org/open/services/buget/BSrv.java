package org.open.services.buget;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class BSrv
 */
@Stateless
public class BSrv implements BSrvLocal {

    /**
     * Default constructor. 
     */
    public BSrv() {
        // TODO Auto-generated constructor stub
    }

}
