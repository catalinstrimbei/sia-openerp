package org.open.services.mdb;
import java.util.Date;

import javax.ejb.Remote;

@Remote
public interface PrxEJBSrv {
	String forwardTopicMessage(Date dataMesaj, String textMesaj);
	String forwardQueueMessage(Date dataMesaj, String textMesaj);
}
