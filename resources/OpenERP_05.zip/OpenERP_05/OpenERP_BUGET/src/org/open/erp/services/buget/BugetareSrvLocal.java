package org.open.erp.services.buget;

import javax.ejb.Local;

@Local
public interface BugetareSrvLocal extends BugetareSrv {

}
