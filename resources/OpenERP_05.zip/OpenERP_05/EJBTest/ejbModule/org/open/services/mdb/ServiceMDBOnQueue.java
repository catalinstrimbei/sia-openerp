package org.open.services.mdb;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.mail.MessageContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.open.services.exjtaref.ExTBigEJBException;


/**
 * Message-Driven Bean implementation class for: ServiceMDB
 *
 */
@MessageDriven(
		activationConfig = {				
				@ActivationConfigProperty(
						propertyName = "destinationType", 
						propertyValue = "javax.jms.Queue"),
				@ActivationConfigProperty(
						propertyName="destination", // or destinationName
						propertyValue="ServiceMDBQueue")						
		}
		//, mappedName = "ServiceMDBQueue"
)
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ServiceMDBOnQueue implements MessageListener {
	Logger logger = Logger.getLogger(this.getClass().getName());
	
	//@Resource
	//private MessageContext context;
	
	@Resource(mappedName="java:jdbc/LocalPG_TX")  //@Resource(mappedName="java:jdbc/FEAA_ORCL_XA")
	private DataSource ds;	
	
	
    /**
     * Default constructor. 
     */
    public ServiceMDBOnQueue() {
        // TODO Auto-generated constructor stub
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void onMessage(Message message) {
        /* Locagica de business aferenta*/
    	try{
    		if (message instanceof MapMessage){
    			MapMessage decodedMessage = (MapMessage) message;
    			Date dataMesaj = new Date(decodedMessage.getLong("dataMesaj"));
    			String textMesaj = decodedMessage.getString("textMesaj");
    			xFirstBusinessAction(dataMesaj, textMesaj);
    		}
    	}catch(Exception ex){
    		logger.error("MDB -> onMessage failed for " + message);
    		ex.printStackTrace();
    	}
    }

    
    /* --------------------------------------------------------- */
	private String xFirstBusinessAction(Date data, String message) {
		String result = " ... do " + message;
		Connection conn = null;
		try{
			/* Set-up section */ 
			conn = ds.getConnection();
			
			/* Tranzactia nu trebuie initializata explicit:
			 * apelul precedent - tranz.implicita - deci REQUIRED, apelul curent - tranz.implicita - deci REQUIRE
			 * */
			Statement stmtx = conn.createStatement();			
			PreparedStatement insert = conn
					.prepareStatement("INSERT INTO \"LOG\" VALUES(?, ?)");
			insert.setTimestamp(1,
					 new java.sql.Timestamp(data.getTime()));
					// new java.sql.Timestamp(new java.util.Date().getTime()));
			insert.setString(2, "1st On QUEUE =" + message);
			insert.execute();
			
			/* Finalize transaction */
			String transactionFlag = message.substring(message.indexOf("[") + 1, message.indexOf("[") + 2);
			if (transactionFlag.equals("1")){
				/* Pentru COMMIT- nimic de facut - inseamna delegarea responsabilitatii super-transactiei
				 * Sub-tranzactia se va comite daca se comite si tranzactia superioara. 
				 * */
				logger.info("COMMIT flag for xFIRST business action - " + transactionFlag);
				logger.info("CONFIRMED xFIRST business action - TF=" + transactionFlag);
			}else{
				logger.info("ROLL flag for xFIRST business action - " + transactionFlag);
				/* Pentru ROLLBACK - [Cum s-ar putea afla daca exista o tranzactie activa, fie BMT fie CMT ?] */
				//context.setRollbackOnly();
				logger.info("ROLLED-BACK MARKED xFIRST business action - TF=" + transactionFlag);
				
				/* Pentru ROLLBACK Varianta 2:
				 * ROLLBACK se va realiza la aruncarea unei exceptii generice
				 * sau un @ApplicationException(rollback=true)
				 * Daca @ApplicationException(rollback=false),
				 * exceptia determina totusi COMMIT 
				 * */
				 throw new MDBException("Exception to ROLLBACK xFIRST business action - TF=" + transactionFlag);				
			}
		}catch(Exception ex){
			logger.error("MDB -> xFirstBusinessAction failed!");
			result = " ... doing " + message + " from xFirstBusinessAction failed!";
			/* Ar trebui apel
			 * context.setRollbackOnly();
			 * */
			if (ex instanceof ExTBigEJBException){
				/* Pentru ROLLBACK Varianta 2: */
				throw (ExTBigEJBException)ex;
			}else
				ex.printStackTrace();			
			
		}finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                System.out.println("Note:  Cleanup exception.");
                e.printStackTrace();
            }
        }
		return result;

	}
	
}

/*
----------------------------------------------------------------------------------------------
deploy\messaging: destinations-service.xml
----------------------------------------------------------------------------------------------
   <mbean code="org.jboss.jms.server.destination.QueueService"
      name="jboss.messaging.destination:service=Queue,name=ServiceMDBQueue"
      xmbean-dd="xmdesc/Queue-xmbean.xml">
	  <attribute name="JNDIName">ServiceMDBQueue</attribute>
      <depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
	  <depends>jboss.messaging:service=PostOffice</depends>
   </mbean>  
----------------------------------------------------------------------------------------------
deploy\messaging: connection-factories-service.xml
----------------------------------------------------------------------------------------------
   <mbean code="org.jboss.jms.server.connectionfactory.ConnectionFactory"
      name="jboss.messaging.connectionfactory:service=ConnectionFactory"
      xmbean-dd="xmdesc/ConnectionFactory-xmbean.xml">
      <depends optional-attribute-name="ServerPeer">jboss.messaging:service=ServerPeer</depends>
      <depends optional-attribute-name="Connector">jboss.messaging:service=Connector,transport=bisocket</depends>
      <depends>jboss.messaging:service=PostOffice</depends>
      
      <attribute name="JNDIBindings">
         <bindings>
            <binding>/ConnectionFactory</binding>
            <binding>/XAConnectionFactory</binding>
            <binding>java:/ConnectionFactory</binding>
            <binding>java:/XAConnectionFactory</binding>
         </bindings>
      </attribute>
   </mbean>
----------------------------------------------------------------------------------------------
*/
