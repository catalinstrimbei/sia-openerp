package org.open.erp.services.buget;

import javax.ejb.Remote;

@Remote
public interface BugetareSrvRemote extends BugetareSrv {

}
