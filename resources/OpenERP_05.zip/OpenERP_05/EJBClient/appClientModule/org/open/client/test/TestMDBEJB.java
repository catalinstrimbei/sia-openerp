package org.open.client.test;

import java.util.Date;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TopicConnectionFactory;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.BeforeClass;
import org.junit.Test;
import org.open.services.exjta.ExTEJBSrv;
import org.open.services.exjtaref.ExFirstEJBSrv;
import org.open.services.exjtaref.ExTBigEJB;
import org.open.services.exjtaref.ExTBigEJBSrv;
import org.open.services.mdb.PrxEJBSrv;

public class TestMDBEJB {
	
	static PrxEJBSrv prxEJB;
	static InitialContext ctx;	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ctx = initJBossJNDICtx(); 
		prxEJB = (PrxEJBSrv) ctx.lookup("PrxEJB/remote");
	}
	
	@Test /* Test transactii MDB cu EJB*/
	public void testDoMessageActionByProxyEJB(){
		String actionResult = prxEJB.forwardTopicMessage(new Date(), "test MDB action - 120 [1]");
		System.out.println(actionResult);
		actionResult = prxEJB.forwardQueueMessage(new Date(), "test MDB action - 121 [1]");
		System.out.println(actionResult);
	}

	@Test /* Test MDB direct*/
	public void testDoMessageActionDirect() throws JMSException{

		
		Date dataMesaj = new Date();
		String textMesaj = "test MDB action - 122 [1]";
		
		String resultJMS = "Success";
		Connection connection = null;
		Session topicSession = null;
		try{
			QueueConnectionFactory queueConnectionFactory =  (QueueConnectionFactory) ctx.lookup("ServiceMDBTopicConnectionFactory");
			Queue queue = (Queue) ctx.lookup("ServiceMDBQueue");			
			
			connection = queueConnectionFactory.createConnection();
			connection.start();
			topicSession = connection.createSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageProducer publisher = topicSession.createProducer(queue);
			MapMessage message =topicSession.createMapMessage();
			message.setLong("dataMesaj", dataMesaj.getTime());
			message.setString("textMesaj", textMesaj + "[ConnectionFactory: ServiceMDBTopicConnectionFactory]");
			publisher.send(message);
			
		}catch(Exception ex){
			ex.printStackTrace();
			resultJMS = "Failed";
			
			if (topicSession != null)
				topicSession.close();
			if (connection != null)
				connection.close();
		}
		
		System.out.println("Forwarding message on queue:" + textMesaj + ": " + resultJMS + "!");
		
	}	
	
	/* JNDI Initialization Context -------------------------------------------------------*/
	private static InitialContext initJBossJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");		
        props.put("java.naming.provider.url", "jnp://localhost:1099/");
        props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
        return new InitialContext(props);
	}	
}