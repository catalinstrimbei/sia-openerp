package org.open.services.exjta;
import javax.ejb.Remote;

@Remote
public interface ExTEJBSrv {
	/* Simple JTA */
	String doBusinessAction(String message); // Bean Managed vs.
	String doBusinessActivity(String message); // Container Managed
	
	/* Direct Distributed JTA with JDBC*/
	String doAggregateBusinessAction(String message);
	String doFirstBusinessAction(String message);
	String doSecondBusinessAction(String message);
	
	/* Declarative Distributed JTA with JDBC*/
	String xAggregateBusinessAction(String message);
	String xFirstBusinessAction(String message);
	String xSecondBusinessAction(String message);
}