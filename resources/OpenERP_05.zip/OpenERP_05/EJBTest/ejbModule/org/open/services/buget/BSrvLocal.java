package org.open.services.buget;
import javax.ejb.Local;

@Local
public interface BSrvLocal {

}
