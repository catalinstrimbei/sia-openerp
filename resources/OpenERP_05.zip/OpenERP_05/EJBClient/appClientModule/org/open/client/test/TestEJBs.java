package org.open.client.test;

import static org.junit.Assert.*;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.open.services.exref.BigEJBSrv;
import org.open.services.test1.Test1;
import org.open.services.test2.Test2;

public class TestEJBs {
	static Test1 test1; 			
	static Test2 test2; 			
	static Test2 test3; 			
	static BigEJBSrv proEJBsrv; 	
	static InitialContext ctx;

	static String test1Name = "Test1Bean/remote";
	static String test2Name = "Test2Bean/remote";
	static String test3Name = "Test2Bean/remote";
	static String proEJBsrvName = "BigEJB/remote";
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ctx = initJBossJNDICtx(); 
		test1 = (Test1) ctx.lookup(test1Name);
		test2 = (Test2) ctx.lookup(test2Name);
		proEJBsrv = (BigEJBSrv) ctx.lookup(proEJBsrvName);
	}

	@Before
	public void setUp() throws Exception {
	}

	//@Test
	public void test1() throws NamingException {
		System.out.println("test1 =" + test1);
		System.out.println(test1.say("Hello!"));
		System.out.println("Just test1: " + test1.getMessage());
		test1 = (Test1) ctx.lookup(test1Name);
		System.out.println("Again: " + test1.getMessage());
	}

	//@Test
	public void test2() throws NamingException {
		System.out.println(test2.say("Hello!"));
		System.out.println("Just test2: " + test2.getMessage());
		test2 = (Test2) ctx.lookup(test2Name);
		System.out.println("Again test2: " + test2.getMessage());		
	}	
	
	//@Test
	public void testBigEJB() throws NamingException {
		System.out.println("BigEJBsrv test1: " + proEJBsrv.sayMessageToTest1("Hello"));
		System.out.println("BigEJBsrv test2: " + proEJBsrv.sayMessageToTest2("Hello"));
		System.out.println("BigEJBsrv test3: " + proEJBsrv.sayMessageToTest3("Hello"));
	}

	//@Test /* Test JTA JDBC */
	public void test4() throws NamingException {
		System.out.println("proEJBsrv =" + proEJBsrv);
		
		String nullMessage = "test";
		System.out.println("------------------------------------------------------------------------");
		System.out.println("Aici ar trebui sa apara mesajul tranzactional: ");
		// Clientul nu are implicit context tranzactional pe care sa-l transmita mai departe
		System.out.println("Transactional proEJBsrv test1: " + proEJBsrv.sayMessageToTest3(nullMessage));
	}
	
	//@Test /* Test Timer */
	
	
	/* JNDI Initialization Context -------------------------------------------------------*/
	private static InitialContext initJBossJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");		
        props.put("java.naming.provider.url", "jnp://localhost:1099/");
        props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
        return new InitialContext(props);
	}
	
	private static InitialContext initGlassfishJNDICtx() throws NamingException{
		Properties props = new Properties();
		/*
        props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.enterprise.naming.SerialInitContextFactory");
        props.setProperty("org.omg.CORBA.ORBInitialHost", "localhost");
        // glassfish default port value will be 3700,
        props.setProperty("org.omg.CORBA.ORBInitialPort", "1099");
        */
        props.put("java.naming.factory.initial", "com.sun.enterprise.naming.SerialInitContextFactory");		
        //props.put("java.naming.provider.url", "jnp://localhost:1099/"); //default
        //props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");		
        return new InitialContext(props);
	}
	
}

/* JBoss's jndi properties
java.naming.factory.initial=org.jnp.interfaces.NamingContextFactory
java.naming.provider.url = iiop://localhost:1099
java.naming.factory.url.pkgs= org.jboss.naming:org.jnp.interfaces
*/

/* Glassfish's jndi properties
java.naming.factory.initial=org.jnp.interfaces.NamingContextFactory
java.naming.provider.url = iiop://localhost:3700
java.naming.factory.url.pkgs= org.jboss.naming:org.jnp.interfaces
*/
