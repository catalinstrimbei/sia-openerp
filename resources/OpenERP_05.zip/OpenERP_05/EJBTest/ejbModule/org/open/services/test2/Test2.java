package org.open.services.test2;

/* Interfaţa de bază din domeniu */
public interface Test2 {
	String say(String mess);
	String getMessage();
}
