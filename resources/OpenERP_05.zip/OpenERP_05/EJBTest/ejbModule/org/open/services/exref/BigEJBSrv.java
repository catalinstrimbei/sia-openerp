package org.open.services.exref;
import javax.ejb.Remote;

@Remote
public interface BigEJBSrv {
	String sayBigEJB(String mess);
	String sayMessageToTest1(String message);
	String sayMessageToTest2(String message);
	String sayMessageToTest3(String message);
}
