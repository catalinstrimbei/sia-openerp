package org.open.services.test2;

/* Interfaţa EJB Local (clientul EJB rulează în acelaşi spaţiu JRE ca şi componenta EJB) */
public interface Test2Local extends Test2 {

}
