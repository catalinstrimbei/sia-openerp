package org.open.services.exref;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptors;
import javax.interceptor.InvocationContext;

import org.apache.log4j.Logger;

public class BigEJBLogInterceptor {
	Logger logger = Logger.getLogger(this.getClass().getName());
	@AroundInvoke
	public Object logMessage(InvocationContext ctx) throws Exception{
		// Decodifica informatii privind contextul de invocare
		Class<? extends Object> targetBeanClass = ctx.getTarget().getClass();
		String invokedMethodName = ctx.getMethod().getName();
		// Executa logica de interceptare
		logger.info("#### call of: " + targetBeanClass.getName() + "." + invokedMethodName);
		// executa metoda interceptata
		return ctx.proceed();
	}
	@AroundInvoke
	public Object logEJBInjection(InvocationContext ctx) throws Exception{
		// Decodifica informatii privind contextul de invocare
		Class<? extends Object> targetBeanClass = ctx.getTarget().getClass();
		String invokedMethodName = ctx.getMethod().getName();
		BigEJB ejbean = (BigEJB) ctx.getTarget();
		
		logger.info("#### call of: " + targetBeanClass.getName() + "." + invokedMethodName);
		// Executa logica de interceptare
		if ("sayMessageTest2".equals(invokedMethodName) && BigEJB.class.equals(targetBeanClass)){
			logger.info("#### test1: " + (ejbean.getTest1()!=null? " is injected, ":" isn't injected, ") +
					"test2: " + (ejbean.getTest2()!=null? " is injected, ":" isn't injected, ")
					);
			//return null;
		}
		// executa metoda interceptata
		return ctx.proceed();
	}
	@AroundInvoke
	public Object logInvocationResult(InvocationContext ctx) throws Exception{
		// Decodifica informatii privind contextul de invocare
		Class targetBeanClass = ctx.getTarget().getClass();
		String invokedMethodName = ctx.getMethod().getName();
		BigEJB ejbean = (BigEJB) ctx.getTarget();
		
		logger.info("#### call of: " + targetBeanClass.getName() + "." + invokedMethodName);
		// Executa logica de interceptare
		if ("sayMessageTest2".equals(invokedMethodName) && BigEJB.class.equals(targetBeanClass)){
			Object invocationResult = ctx.proceed();
			logger.info("#### invocationResult message: " + invocationResult);
			return invocationResult;
		}
		// executa metoda interceptata
		return ctx.proceed();
	}
	
}
