package org.open.services.test1;

/* Interfaţa de bază din domeniu */
public interface Test1 {
	String say(String mess);
	String getMessage();
}
