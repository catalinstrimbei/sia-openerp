package org.open.services.test1;

import javax.ejb.Local;

/* Interfaţa EJB Local (clientul EJB rulează în acelaşi spaţiu JRE ca şi componenta EJB) */
@Local
public interface Test1Local extends Test1 {

}
