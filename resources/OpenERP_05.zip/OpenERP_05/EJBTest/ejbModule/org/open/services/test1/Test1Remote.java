package org.open.services.test1;

import javax.ejb.Remote;

/* Interfaţa EJB Remote (clientul EJB rulează în alt spaţiu JRE faţă de componenta EJB) */
@Remote
public interface Test1Remote extends Test1 {

}
