package org.open.services.exjtaref;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class ExTBigEJBException extends RuntimeException{

	public ExTBigEJBException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExTBigEJBException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
