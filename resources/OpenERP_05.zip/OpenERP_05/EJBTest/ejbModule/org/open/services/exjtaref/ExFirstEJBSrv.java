package org.open.services.exjtaref;

import javax.ejb.Local;

@Local
public interface ExFirstEJBSrv {
	/* Part of Declarative Distributed JTA with JDBC*/
	String xFirstBusinessAction(String message);
}
