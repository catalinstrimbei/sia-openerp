package org.open.services.exjtaref;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.ApplicationException;
import javax.ejb.EJB;
import javax.ejb.PostActivate;
import javax.ejb.PrePassivate;
import javax.ejb.Remove;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.sql.XAConnection;
import javax.sql.XADataSource;
import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;
import javax.transaction.xa.XAResource;

import org.apache.log4j.Logger;
import org.open.services.test1.Test1Local;
import org.open.services.test2.Test2Local;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ExTBigEJB implements ExTBigEJBSrv {
	Logger logger = Logger.getLogger(this.getClass().getName());
    public ExTBigEJB() { }	
	
	/* Resurse injectatate */
	@Resource
	private SessionContext context;	
	@Resource(mappedName="java:jdbc/LocalPG_XA")
	private DataSource ds;
	/* INTERCEPTORI  Life cycle */
	@PostConstruct
	void init(){
		//initializeaza resurse neinjectate (folosind, de obicei, SessionContext)
		logger.info("**** @PostConstruct: initializeaza resurse neinjectate (folosind, de obicei, SessionContext)!");		
	}	    
	@PrePassivate
	public void onPassivate() {
		//inchide conexiunile externe si seteaza null toti membrii neserializabili
		logger.info("**** @PrePassivate: inchide conexiunile externe si seteaza null toti membrii neserializabili!");
	}
	@PostActivate
	public void onActivate() {
		//redeschide conexiunile si initializeaza membrii non-serializabili
		logger.info("**** @PostActivate: redeschide conexiunile si initializeaza membrii non-serializabili!");
	}
	@Remove
	public void disconnect() {
		//sterge obiectul, din memoria serverului, la invocarea acestei metode
		logger.info("**** disconnect: sterge obiectul, din memoria serverului, la invocarea acestei metode!");
	}
	@PreDestroy
	public void closeFile() {
		//containerul va invoca aceasta metoda inainte de distrugerea obiectului
		logger.info("**** @PreDestroy: containerul va invoca aceasta metoda inainte de distrugerea obiectului!");
	}
	
	/*--------------------------------------*/
	private static InitialContext initJBossJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");		
        props.put("java.naming.provider.url", "jnp://localhost:1099/");
        props.put("java.naming.factory.url.pkgs", "org.jboss.naming:org.jnp.interfaces");
        return new InitialContext(props);
	}
	/*private static InitialContext initGlassfishJNDICtx() throws NamingException{
		Properties props = new Properties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.enterprise.naming.SerialInitContextFactory");
        props.setProperty("org.omg.CORBA.ORBInitialHost", "localhost");
        // glassfish default port value will be 3700,
        props.setProperty("org.omg.CORBA.ORBInitialPort", "3700");	
        return new InitialContext(props);
	}	*/
	
	
	/* Servicii business oferite ***********************************************************************/
	/* EJB Refs Injected*/
	@EJB
	private ExFirstEJBSrv firstEJB;
	
	@EJB
	private ExSecondEJBSrv secondEJB;
	
	/* Pre-conditii context EJB:
	 * @TransactionManagement(TransactionManagementType.CONTAINER)
	 * si, in mod implicit,
	 * @TransactionAttribute(TransactionAttributeType.REQUIRED)
	 */	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	@Override
	public String xAggregateBusinessAction(String message) {
		
		String resultAggreggate = null; 
				
		try {
			/* Tranzactia NU trebuie initializata explicit - este initializata IMPLICIT (Default CMP REQUIRED)
			 * adica NU SE POATE PUNE mana pe obiectul JTA javax.transaction.UserTransaction
			 * si deci nu se poate manipula explicit ...
			 * 
			 * */
			
			String resultFBA =  "";
			try{
				resultFBA =  firstEJB.xFirstBusinessAction(message);
			}catch(ExTBigEJBException ex){
				logger.info("Exception for ROLLBACK from xFirstBusinessAction call!"); 
			}			
			
			String resultSBA =  " **** ";
			try{
				resultSBA =  secondEJB.xSecondBusinessAction(message);
			}catch(ExTBigEJBException ex){
				logger.info("Exception for ROLLBACK from xSecondBusinessAction call!"); 
			}
			
			resultAggreggate = resultFBA + resultSBA;
			
			/* Finalize transaction */
			String transactionFlag = message.substring(message.indexOf("[") + 1, message.indexOf("[") + 2);
			if (transactionFlag.equals("1")){
				logger.info("COMMIT flag for business  X-AGGREGATE - " + transactionFlag);
				/* Daca s-a marcat rollback din sub-tranzactii*/
				if (context.getRollbackOnly()){
					/* Nu mai e necesar apelul 
					 * context.setRollbackOnly();
					 * Anularea sub-T va determina anularea super-T.
					 * */
					logger.info("ROLLBACK implicit - business X-AGGREGATE - TF=" + transactionFlag); 
				}else{
					/* Pentru COMMIT Nimic de facut ... */
					logger.info("COMMITED MARKED DEFAULT business  X-AGGREGATE - TF=" + transactionFlag);
				}
			}else{
				logger.info("ROLL flag for business X-AGGREGATE - " + transactionFlag);
				/* Pentru ROLLBACK*/
				context.setRollbackOnly();
				logger.info("ROLLBACK explicit - business  X-AGGREGATE - TF=" + transactionFlag);
				
				/* Pentru ROLLBACK Varianta 2:
				 * ROLLBACK se va realiza la aruncarea unei exceptii generice
				 * sau un @ApplicationException(rollback=true)
				 * Daca @ApplicationException(rollback=false),
				 * exceptia determina totusi COMMIT 
				 * */
				 //throw new ExTEJBException();						
			}			
			
		} catch (Exception ex) {
			logger.error("ExTEJB -> xAggregateBusinessAction failed!");
			resultAggreggate = " ... doing " + message + " from xAggregateBusinessAction failed!";
			ex.printStackTrace();
		}
		
		return resultAggreggate;

	}
}
