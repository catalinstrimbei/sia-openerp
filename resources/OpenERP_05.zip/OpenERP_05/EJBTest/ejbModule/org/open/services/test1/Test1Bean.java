package org.open.services.test1;

import javax.ejb.Stateless;

/*Clasa de implementare componenta EJB stateless, eventual cu declaraţia numelui JNDI
 * Pentru portabilitate intre containere EJB diferite nu se recomanda declararea explicita
 *  a numelor JNDI prin param. name sau mappedName
 * */

//@Stateless(mappedName="Test1Bean/remote")
@Stateless //Numele default in JBoss <NumeClasaEJBean>/remote si <NumeClasaEJBean>/local
public class Test1Bean implements Test1Remote, Test1Local{
	public String say(String mess){
		this.message = mess;
		return "Test1Bean say:" + mess;
	}

	/* Test conversational */
	private String message = "Default";
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
