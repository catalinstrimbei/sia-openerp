package org.open.services.exjtaref;
import javax.ejb.Remote;

@Remote
public interface ExTBigEJBSrv {	
	/* Declarative Distributed JTA with JDBC*/
	String xAggregateBusinessAction(String message);
	// String xFirstBusinessAction(String message); - ExFirstEJB.businessAction
	// String xSecondBusinessAction(String message); - ExSecondEJB.businessAction
}